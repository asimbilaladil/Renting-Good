<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">

             <li class="treeview">
                <a href="<?php echo site_url('admin'); ?>"><i class="fa fa-desktop"></i> <span>Home</span></a>                
            </li>

            <li class="treeview">
                <a href="<?php echo site_url('admin/addNewCustomField'); ?>"><i class="fa fa-desktop"></i> <span>Add New Custom Field</span></a>                
            </li>
             <li class="treeview">
                <a href="<?php echo site_url('admin/addJK'); ?>"><i class="fa fa-desktop"></i> <span>Add JK</span></a>                
            </li>
             <li class="treeview">
                <a href="<?php echo site_url('admin/addDuty'); ?>"><i class="fa fa-desktop"></i> <span>Add Duty</span></a>                
            </li>

             <li class="treeview">
                <a href="<?php echo site_url('admin/user'); ?>"><i class="fa fa-user"></i> <span>User</span></a>                
            </li>
        <li class="treeview">
                <a href="<?php echo site_url('admin/news'); ?>"><i class="fa fa-desktop"></i> <span>Latest News</span></a>                
            </li>

            <li class="treeview">
                <a href="<?php echo site_url('admin/assignedDuties'); ?>"><i class="fa fa-user"></i> <span>Assigned Duties</span></a>                
            </li>

            <li class="treeview">
                <a href="<?php echo site_url('admin/request'); ?>"><i class="fa fa-user"></i> <span>User Requests</span></a>                
            </li>
            <li class="treeview">
                <a href="<?php echo site_url('admin/logout'); ?>"><i class="fa fa-user"></i> <span>Logout</span></a>                
            </li>



        </ul>
    </section>
    <!-- /.sidebar -->
</aside>