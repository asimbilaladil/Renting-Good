    <!-- Footer Start -->
    <footer id="footer"> 
      
        <div class="cs-copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <div class="copyright-text">
                            <p>© 2016 Waara | All Rights Reserved.<a class="cs-color" href="#"> Develop by Asim Bilal</a></p>
                        </div>
                    </div>
          
                </div>
            </div>
        </div>
        
        
    </footer>
    <!-- Footer End --> 
</div>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>includes/search.js"></script>   

<script src="<?php echo base_url("includes/website/assets/scripts/responsive.menu.js") ?> "></script> <!-- Slick Nav js --> 
<script src="<?php echo base_url("includes/website/assets/scripts/chosen.select.js") ?> "></script> <!-- Chosen js --> 
<script src="<?php echo base_url("includes/website/assets/scripts/slick.js") ?> "></script> <!-- Slick Slider js --> 
<script src="<?php echo base_url("includes/website/assets/scripts/jquery.mCustomScrollbar.concat.min.js") ?> "></script> 
<script src="<?php echo base_url("includes/website/assets/scripts/jquery.mobile-menu.min.js") ?> "></script><!-- Side Menu js --> 
<script src="<?php echo base_url("includes/website/assets/scripts/counter.js") ?> "></script><!-- Counter js --> 

<!-- Put all Functions in functions.js --> 
<script src="<?php echo base_url("includes/website/assets/scripts/functions.js") ?> "></script>
</body>
</html>